
class OuterClass {
    private int outerVar = 10;

    
    class InnerClass {
        void display() {
            System.out.println("InnerClass Display: OuterVar = " + outerVar);
        }
    }

   
    static class StaticNestedClass {
        void display() {
            System.out.println("StaticNestedClass Display");
        }
    }

   
    void anonymousInnerClassExample() {
 
        Runnable runnable = new Runnable() {
           
            public void run() {
                System.out.println("Anonymous Inner Class: Runnable Interface");
            }
        };
        new Thread(runnable).start();
    }
}

public class InnerClassesExample {

    public static void main(String[] args) {
      
        OuterClass outerObject = new OuterClass();

        
        OuterClass.InnerClass innerObject = outerObject.new InnerClass();
        innerObject.display();

     
        OuterClass.StaticNestedClass staticNestedObject = new OuterClass.StaticNestedClass();
        staticNestedObject.display();

    
        outerObject.anonymousInnerClassExample();
    }
}